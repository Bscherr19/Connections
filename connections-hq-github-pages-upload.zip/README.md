# Connections HQ: Early Careers Edition

Connections HQ is a static, mobile-friendly event hub for Early Careers Week. It is designed for a QR-code experience where participants can quickly find the schedule, location details, connection prompts, showcase guidance, resources, and reflection notes.

The layout is responsive: phones use a sticky bottom navigation bar for fast event-day access, while desktop screens use a top navigation and wider card grids for planning or presenting.

## Files

- `index.html` - page structure and section content
- `styles.css` - visual design and responsive layout
- `script.js` - agenda data, prompts, bingo, challenges, resources, and local saving
- `hero-event.png` - generated hero image used on the homepage

## How to Edit the Schedule

Open `script.js` and find the `scheduleData` object near the top. Each day has a list of agenda cards with:

- `time`
- `title`
- `location`
- `audience`
- `description`

Edit those values directly. Add or remove agenda objects as needed.

## How to Edit Prompts and Challenges

Open `script.js` and update:

- `prompts` for the random networking prompt generator
- `challenges` for Mayhem Move of the Moment
- `bingoItems` for Connection Bingo squares

## How to Replace Placeholder Links

Open `script.js` and update the `resources` array. Replace each `href: "#"` with a Microsoft Forms, SharePoint, Google Form, or other resource link.

In `index.html`, the Showcase buttons also use placeholder `href="#"` links:

- Sign Up to Share
- Submit a Hidden Gem
- Vote / Reflect

Replace those with the final form links when ready.

## How to Run Locally

Open `index.html` in a browser. No server is required.

If you want to test it through a local web address, run a simple static server from this folder and open the localhost URL in your browser.

## How to Deploy as a Static Site

Upload these files to any static hosting option:

- `index.html`
- `styles.css`
- `script.js`
- `hero-event.png`
- `README.md`

Good options include GitHub Pages, Netlify Drop, SharePoint pages with an embedded hosted link, or any static web host your organization approves.

## Safety and Privacy Note

This app does not use logins, databases, tracking, analytics, or a backend. Bingo checks and reflection notes save only in the participant's current browser on the current device through local browser storage.

The event contact phone number from the source deck was not placed in the app, so the public version avoids exposing a direct personal number by default.
