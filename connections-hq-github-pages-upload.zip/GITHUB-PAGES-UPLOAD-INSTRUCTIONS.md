# Connections HQ GitHub Pages Upload Instructions

## Upload These Files

Upload these files together at the root of your GitHub Pages repo or branch:

- `index.html`
- `styles.css`
- `script.js`
- `hero-event.png`
- `.nojekyll`

Do not put them inside an extra nested folder unless your GitHub Pages settings are pointed to that folder. The safest setup is for `index.html` to be directly visible in the repo root.

## Quick GitHub Pages Steps

1. Open your GitHub repository.
2. Upload the files from the `connections-hq-github-pages-upload` folder.
3. Go to **Settings**.
4. Go to **Pages**.
5. Under **Build and deployment**, choose **Deploy from a branch**.
6. Choose the branch you uploaded to, usually `main`.
7. Choose `/root`.
8. Save.

GitHub will give you a live site link after it finishes publishing. It may take a few minutes.

## After Uploading

Open the GitHub Pages link and check:

- The hero image loads.
- The Schedule tab works.
- The Connect prompts generate.
- The Resource and Showcase buttons have real links if you are ready to share publicly.

## Before Sharing Publicly

Replace placeholder `#` links with final Microsoft Forms, SharePoint, or resource links:

- Showcase sign-up
- Hidden Gem submission
- Vote / Reflect
- Resource cards

Those links are edited in `index.html` and `script.js`.
